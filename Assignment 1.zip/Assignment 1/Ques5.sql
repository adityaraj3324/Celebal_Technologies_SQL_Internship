SELECT Name  
FROM Production.Product  
ORDER BY Name;
