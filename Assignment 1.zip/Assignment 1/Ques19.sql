SELECT * 
FROM Sales.SalesOrderHeader 
WHERE TotalDue > 200;
