SELECT * FROM Sales.Customer;


