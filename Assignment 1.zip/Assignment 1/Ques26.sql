SELECT FirstName, LastName
FROM Person.Person
WHERE FirstName LIKE '%a%';
