SELECT DISTINCT CustomerID 
FROM Sales.SalesOrderHeader;
