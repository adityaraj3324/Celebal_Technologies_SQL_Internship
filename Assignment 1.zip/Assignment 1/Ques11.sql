SELECT TOP 1 * 
FROM Sales.SalesOrderHeader 
ORDER BY OrderDate ASC;
