SELECT TOP 1 OrderDate, TotalDue 
FROM Sales.SalesOrderHeader 
ORDER BY TotalDue DESC;
