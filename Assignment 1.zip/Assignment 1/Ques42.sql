SELECT SUM(TotalDue) AS Revenue
FROM Sales.SalesOrderHeader;
